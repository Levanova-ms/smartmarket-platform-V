var signer = require('./signer');
var https = require("https");
var sig = new signer.Signer();
sig.Key = "apigateway_sdk_demo_key";
sig.Secret = "apigateway_sdk_demo_secret";

var r = new signer.HttpRequest("POST", "30030113-3657-4fb6-a7ef-90764239b038.apigw.exampleRegion.com/app1?query=value");
r.headers = {"x-stage": "RELEASE"};
r.body = '{"a":1}';

var opt = sig.Sign(r);
console.log(opt.headers["X-Sdk-Date"]);
console.log(opt.headers["Authorization"]);

var req = https.request(opt, function (res) {
    console.log(res.statusCode);
    console.log('headers:', JSON.stringify(res.headers));
    res.on("data", function (chunk) {
        console.log(chunk.toString())
    })
});

req.on("error", function (err) {
    console.log(err.message)
});
req.write(r.body);
req.end();
